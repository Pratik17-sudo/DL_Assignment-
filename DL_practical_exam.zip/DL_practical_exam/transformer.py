import torch
import torch.nn as nn
import torch.optim as optim
import pandas as pd
from torch.utils.data import Dataset, DataLoader, random_split
from torch.nn.utils.rnn import pad_sequence
import math
import nltk
from nltk.translate.bleu_score import sentence_bleu, SmoothingFunction
from nltk.translate.meteor_score import meteor_score
from rouge_score import rouge_scorer
import warnings
warnings.filterwarnings('ignore')

# Initialize NLTK
nltk.download('punkt', quiet=True)
nltk.download('wordnet')  # Required for METEOR

# Hyperparameters
BATCH_SIZE = 32
NUM_EPOCHS = 20
LEARNING_RATE = 0.0005
D_MODEL = 256
NUM_HEADS = 4
NUM_LAYERS = 3
DROPOUT = 0.1
MAX_LEN = 128
WARMUP_STEPS = 4000
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Load Full Dataset
try:
    df = pd.read_csv("news_summary.csv", encoding="latin-1")
    texts = df["text"].tolist()
    headlines = df["headlines"].tolist()
except FileNotFoundError:
    print("Error: news_summary.csv not found in directory")
    exit()

# Tokenization and Vocabulary
vocab = set()
for text in texts + headlines:
    for word in nltk.word_tokenize(text.lower()):
        vocab.add(word)
vocab = ["<PAD>", "<SOS>", "<EOS>", "<UNK>"] + sorted(vocab)
word2idx = {word: idx for idx, word in enumerate(vocab)}
idx2word = {idx: word for idx, word in enumerate(vocab)}
VOCAB_SIZE = len(vocab)

# Dataset Class
class HeadlineDataset(Dataset):
    def __init__(self, texts, headlines, word2idx):
        self.texts = texts
        self.headlines = headlines
        self.word2idx = word2idx

    def __len__(self):
        return len(self.texts)

    def __getitem__(self, idx):
        text = self.texts[idx]
        headline = self.headlines[idx]

        text_indices = [self.word2idx["<SOS>"]] + \
                      [self.word2idx.get(word.lower(), self.word2idx["<UNK>"]) 
                       for word in nltk.word_tokenize(text)[:MAX_LEN-2]] + \
                      [self.word2idx["<EOS>"]]
        
        headline_indices = [self.word2idx["<SOS>"]] + \
                          [self.word2idx.get(word.lower(), self.word2idx["<UNK>"]) 
                           for word in nltk.word_tokenize(headline)[:MAX_LEN-2]] + \
                          [self.word2idx["<EOS>"]]

        return torch.tensor(text_indices), torch.tensor(headline_indices)

# Padding function
def collate_fn(batch):
    src_batch, tgt_batch = zip(*batch)
    src_batch = pad_sequence(src_batch, padding_value=word2idx["<PAD>"], batch_first=True)
    tgt_batch = pad_sequence(tgt_batch, padding_value=word2idx["<PAD>"], batch_first=True)
    return src_batch, tgt_batch

# Transformer Model
class Transformer(nn.Module):
    def __init__(self):
        super().__init__()
        self.embedding = nn.Embedding(VOCAB_SIZE, D_MODEL)
        self.pos_encoder = PositionalEncoding(D_MODEL, DROPOUT)
        self.transformer = nn.Transformer(
            d_model=D_MODEL,
            nhead=NUM_HEADS,
            num_encoder_layers=NUM_LAYERS,
            num_decoder_layers=NUM_LAYERS,
            dropout=DROPOUT,
            batch_first=True
        )
        self.fc = nn.Linear(D_MODEL, VOCAB_SIZE)
        self.init_weights()

    def init_weights(self):
        for p in self.parameters():
            if p.dim() > 1:
                nn.init.xavier_uniform_(p)

    def forward(self, src, tgt):
        src = self.embedding(src) * math.sqrt(D_MODEL)
        tgt = self.embedding(tgt) * math.sqrt(D_MODEL)
        src = self.pos_encoder(src)
        tgt = self.pos_encoder(tgt)
        
        src_key_padding_mask = (src == word2idx["<PAD>"])[:, :, 0]
        tgt_key_padding_mask = (tgt == word2idx["<PAD>"])[:, :, 0]
        tgt_mask = self.generate_square_subsequent_mask(tgt.size(1)).to(DEVICE)
        
        output = self.transformer(
            src, 
            tgt,
            tgt_mask=tgt_mask,
            src_key_padding_mask=src_key_padding_mask,
            tgt_key_padding_mask=tgt_key_padding_mask
        )
        return self.fc(output)
    
    def generate_square_subsequent_mask(self, sz):
        return torch.triu(torch.ones(sz, sz) * float('-inf'), diagonal=1)

class PositionalEncoding(nn.Module):
    def __init__(self, d_model, dropout, max_len=MAX_LEN):
        super().__init__()
        self.dropout = nn.Dropout(p=dropout)
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        self.register_buffer("pe", pe)

    def forward(self, x):
        x = x + self.pe[:x.size(1), :]
        return self.dropout(x)

# Learning Rate Scheduling
def get_lr(step):
    return D_MODEL**-0.5 * min((step + 1)**-0.5, (step + 1) * WARMUP_STEPS**-1.5)

# Evaluation Metrics
def calculate_metrics(reference, hypothesis):
    """Calculate BLEU, ROUGE, and METEOR scores"""
    smooth = SmoothingFunction().method1
    
    # BLEU Score
    bleu = sentence_bleu([reference], hypothesis, smoothing_function=smooth)
    
    # ROUGE Score
    scorer = rouge_scorer.RougeScorer(['rouge1', 'rouge2', 'rougeL'], use_stemmer=True)
    rouge_scores = scorer.score(' '.join(reference), ' '.join(hypothesis))
    
    # METEOR Score
    meteor = meteor_score([reference], hypothesis)
    
    return {
        'bleu': bleu,
        'rouge1': rouge_scores['rouge1'].fmeasure,
        'rouge2': rouge_scores['rouge2'].fmeasure,
        'rougeL': rouge_scores['rougeL'].fmeasure,
        'meteor': meteor
    }

# Training Function
def train():
    # Prepare data
    dataset = HeadlineDataset(texts, headlines, word2idx)
    train_size = int(0.8 * len(dataset))
    val_size = len(dataset) - train_size
    train_dataset, val_dataset = random_split(dataset, [train_size, val_size])
    
    train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, 
                            shuffle=True, collate_fn=collate_fn)
    val_loader = DataLoader(val_dataset, batch_size=BATCH_SIZE, 
                          collate_fn=collate_fn)

    # Initialize model
    model = Transformer().to(DEVICE)
    criterion = nn.CrossEntropyLoss(
        ignore_index=word2idx["<PAD>"],
        label_smoothing=0.1
    ).to(DEVICE)
    optimizer = optim.Adam(model.parameters(), lr=LEARNING_RATE, betas=(0.9, 0.98), eps=1e-9)
    
    best_val_loss = float('inf')
    step = 0
    
    for epoch in range(NUM_EPOCHS):
        model.train()
        total_loss = 0
        
        for batch_idx, (src, tgt) in enumerate(train_loader):
            # Update learning rate
            lr = get_lr(step)
            for param_group in optimizer.param_groups:
                param_group['lr'] = lr
            step += 1
            
            src, tgt = src.to(DEVICE), tgt.to(DEVICE)
            
            optimizer.zero_grad()
            output = model(src, tgt[:, :-1])
            loss = criterion(output.reshape(-1, VOCAB_SIZE), tgt[:, 1:].reshape(-1))
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 0.5)
            optimizer.step()
            
            total_loss += loss.item()
            
            if batch_idx % 50 == 0:
                print(f"Epoch {epoch+1}/{NUM_EPOCHS} | Batch {batch_idx}/{len(train_loader)} | Loss: {loss.item():.4f} | LR: {lr:.6f}")
        
        # Validation with Metrics
        model.eval()
        val_loss = 0
        total_metrics = {
            'bleu': 0,
            'rouge1': 0,
            'rouge2': 0,
            'rougeL': 0,
            'meteor': 0
        }
        num_samples = 0
        
        with torch.no_grad():
            for src, tgt in val_loader:
                src, tgt = src.to(DEVICE), tgt.to(DEVICE)
                output = model(src, tgt[:, :-1])
                val_loss += criterion(output.reshape(-1, VOCAB_SIZE), tgt[:, 1:].reshape(-1)).item()
                
                # Convert predictions to text for metrics
                preds = output.argmax(dim=-1)
                for i in range(preds.size(0)):
                    # Get reference and hypothesis texts
                    ref_tokens = [idx2word[idx.item()] for idx in tgt[i][1:] 
                                if idx.item() not in [word2idx["<PAD>"], word2idx["<EOS>"]]]
                    hyp_tokens = [idx2word[idx.item()] for idx in preds[i] 
                                if idx.item() not in [word2idx["<PAD>"], word2idx["<EOS>"]]]
                    
                    if len(ref_tokens) > 0 and len(hyp_tokens) > 0:
                        metrics = calculate_metrics(ref_tokens, hyp_tokens)
                        for key in total_metrics:
                            total_metrics[key] += metrics[key]
                        num_samples += 1
        
        if num_samples > 0:
            avg_val_loss = val_loss / len(val_loader)
            avg_metrics = {k: v/num_samples for k, v in total_metrics.items()}
        else:
            avg_val_loss = float('inf')
            avg_metrics = {k: 0.0 for k in total_metrics}
        
        print(f"\nEpoch {epoch+1}/{NUM_EPOCHS} Summary:")
        print(f"Train Loss: {total_loss/len(train_loader):.4f} | Val Loss: {avg_val_loss:.4f}")
        print("Validation Metrics:")
        print(f"BLEU: {avg_metrics['bleu']:.4f} | ROUGE-1: {avg_metrics['rouge1']:.4f}")
        print(f"ROUGE-2: {avg_metrics['rouge2']:.4f} | ROUGE-L: {avg_metrics['rougeL']:.4f}")
        print(f"METEOR: {avg_metrics['meteor']:.4f}")
        print("-" * 60)
        
        # Save best model
        if avg_val_loss < best_val_loss:
            best_val_loss = avg_val_loss
            torch.save(model.state_dict(), "best_headline_generator.pth")
            print("New best model saved!")
    
    # Save final model
    torch.save(model.state_dict(), "final_headline_generator.pth")
    print("Training complete. Final model saved.")

if __name__ == "__main__":
    train()
