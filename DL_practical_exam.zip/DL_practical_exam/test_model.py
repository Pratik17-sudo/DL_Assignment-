import torch
import nltk
from transformer import Transformer, word2idx, idx2word, MAX_LEN, DEVICE

# Load saved model
model = Transformer().to(DEVICE)
model.load_state_dict(torch.load("final_headline_generator.pth"))
model.eval()

def generate_headline(text):
    tokens = [word2idx["<SOS>"]] + \
             [word2idx.get(word.lower(), word2idx["<UNK>"]) 
              for word in nltk.word_tokenize(text)[:MAX_LEN-1]]
    
    src = torch.tensor(tokens, dtype=torch.long).unsqueeze(0).to(DEVICE)
    tgt = torch.tensor([[word2idx["<SOS>"]]], dtype=torch.long).to(DEVICE)
    
    for _ in range(MAX_LEN):
        with torch.no_grad():
            output = model(src, tgt)
            next_token = output.argmax(dim=-1)[:,-1].item()
            
            if next_token == word2idx["<EOS>"]:  # Stop if EOS is generated
                break
                
            tgt = torch.cat([
                tgt, 
                torch.tensor([[next_token]], device=DEVICE)
            ], dim=1)
    
    # Filter out special tokens
    headline = [
        idx2word[idx.item()] 
        for idx in tgt[0][1:]  # Skip SOS
        if idx.item() not in {word2idx["<EOS>"], word2idx["<PAD>"], word2idx["<SOS>"]}
    ]
    return " ".join(headline) if headline else "[No headline generated]"
# Test with sample news articles
test_articles = [
    "The government announced new economic policies today that will affect all sectors.",
    "Scientists discovered a new species of dinosaur in Argentina that lived 70 million years ago.",
    "The tech company unveiled its latest smartphone with revolutionary camera technology."
]

for article in test_articles:
    headline = generate_headline(article)
    print(f"\nArticle: {article}")
    print(f"Generated Headline: {headline}")